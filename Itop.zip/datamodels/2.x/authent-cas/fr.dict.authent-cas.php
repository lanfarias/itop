<?php
/**
 * Localized data
 *
 * @copyright   Copyright (C) 2013 XXXXX
 * @license     http://opensource.org/licenses/AGPL-3.0
 */
Dict::Add('FR FR', 'French', 'Français', array(
	'CAS:Error:UserNotAllowed' => 'Utilisateur non autorisé',
	'CAS:Login:SignIn' => 'S\'identifier avec CAS',
	'CAS:Login:SignInTooltip' => 'Cliquer ici pour s\'identifier avec le serveur CAS',
));
