= Make Doc =
.make folder is meant to gather tools for releasing process. Maybe other new purposes will come as well....

== license ==
- updateLicenses.php: used to update community-licenses.xml easily based on composer.json files
- sortLicenceXml.php: used to sort licenses based on scope + product name